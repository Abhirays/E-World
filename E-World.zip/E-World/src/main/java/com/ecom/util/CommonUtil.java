package com.ecom.util;

import java.io.UnsupportedEncodingException;
import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.ecom.model.ProductOrder;
import com.ecom.model.UserDtls;
import com.ecom.service.UserService;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpServletRequest;

@SuppressWarnings("unused")
@Component
public class CommonUtil {

	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private UserService userService;

	public Boolean sendMail(String url, String reciepentEmail) {
	    try {
	        MimeMessage message = mailSender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message);

	        helper.setFrom("abhi47200247@gmail.com", "Shopping Cart");
	        helper.setTo(reciepentEmail);

	        String content = "<p>Hello,</p>" + 
	                         "<p>You have requested to reset your password.</p>" +
	                         "<p>Click the link below to change your password:</p>" +
	                         "<p><a href=\"" + url + "\">Change my password</a></p>";
	        helper.setSubject("Password Reset");
	        helper.setText(content, true);
	        mailSender.send(message);
	        return true;
	    } catch (UnsupportedEncodingException | MessagingException e) {
	        // Log the error and handle it
	        e.printStackTrace();
	        return false;
	    }
	}

	public void sendMailForProductOrder(ProductOrder saveOrder, String string) {
		// TODO Auto-generated method stub
		
	}

	public UserDtls getLoggedInUserDetails(Principal p) {
		// TODO Auto-generated method stub
		return null;
	}

	public static String generateUrl(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}}
